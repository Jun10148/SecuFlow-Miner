# SecuFLow-UG2-SEP-2024
Make sure you have Docker installed in your host machine
Clone the repo from Github to host machine. Open the folder in Visual Studio Code. When you see Reopen in Container, click on that to set up Docker container.

To start the site

open two terminals
first
navigate to SecuFLow-UG2-SEP-2024\app\node-server\client>
```bash
npm install
npm run build
```
second:
navigate to SecuFLow-UG2-SEP-2024\app\node-server>
```bash
npm install
pip3 install numpy --break-system-packages
npm start
```

Open [http://localhost:8089](http://localhost:8089) with your browser to see the result.


To use the site

clone or copy a repository into app/node-server/miner/tnm-main

input the repository name into the text input on the home page
