package cli.gitMinersCLI.base

import cli.AbstractRepoCLI

abstract class GitMinerCLI(name: String, help: String) : AbstractRepoCLI(name, help)
