package cli.calculculationsCLI

import cli.AbstractCLI

abstract class CalculationCLI(name: String, help: String) : AbstractCLI(name, help)
