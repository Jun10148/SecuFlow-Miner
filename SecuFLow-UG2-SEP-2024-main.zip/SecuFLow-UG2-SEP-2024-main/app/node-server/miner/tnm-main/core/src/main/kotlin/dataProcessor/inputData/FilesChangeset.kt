package dataProcessor.inputData

data class FilesChangeset(val changeset: Set<String>) : InputData