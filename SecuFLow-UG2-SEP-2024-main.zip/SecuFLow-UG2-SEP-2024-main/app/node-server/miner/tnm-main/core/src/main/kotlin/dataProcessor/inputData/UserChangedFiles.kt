package dataProcessor.inputData

data class UserChangedFiles(val user: String, val files: Set<String>) : InputData