package dataProcessor.inputData

import java.util.*


data class UserCommitDate(val user: String, val date: Date) : InputData