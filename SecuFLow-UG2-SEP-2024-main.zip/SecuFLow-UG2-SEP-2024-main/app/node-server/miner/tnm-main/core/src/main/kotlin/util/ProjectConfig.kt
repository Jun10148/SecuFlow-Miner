package util

object ProjectConfig {
    val DEFAULT_NUM_THREADS = Runtime.getRuntime().availableProcessors()
}
