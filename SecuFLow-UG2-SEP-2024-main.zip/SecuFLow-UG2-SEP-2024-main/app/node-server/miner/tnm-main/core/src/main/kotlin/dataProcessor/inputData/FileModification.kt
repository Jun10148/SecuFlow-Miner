package dataProcessor.inputData

data class FileModification(val filePath: String, val modifications: Int) : InputData