#!/usr/bin/env bash
 java -jar ./cli/build/libs/shadow-*.jar "$@"
